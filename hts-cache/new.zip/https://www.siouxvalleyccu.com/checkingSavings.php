<!docType html>
<html lang="en">
    <head>
    	<meta charset="UTF-8"> 
        <meta name='viewport' content='width=device-width'>
        <title> Sioux Valley Community Credit Union: Checking & Savings </title>
        <link rel="stylesheet" type="text/css" href="/_inc/style.css?040219">  
        <link rel="stylesheet" type="text/css" href="/_inc/respond.css"> 
            <link rel="stylesheet" type="text/css" href="/_inc/flexslider.css">
            <link rel="stylesheet" type="text/css" href="/_inc/rmm.css"> 
             <link rel="icon" type="image/png" href="/images/icon.png" />
            <link href="https://fonts.googleapis.com/css?family=Acme" rel="stylesheet">
            <link href="https://fonts.googleapis.com/css?family=Archivo+Black" rel="stylesheet">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8/jquery.min.js"></script>
<script src="/sab/jquery-ultimate-smartbanner.js"></script>
            

    </head>
    <body>
    
        <header class="contain">
            
            	<div id="topNavListBar">
                <ul id="navList">
                    <li><a href="/index.php">Home</a></li> |
                     <li><a href="/locations.php">Locations</a></li> |
                    <li><a href="/contactus.php">Contact Us</a></li>
                </ul>
                </div>
                
                <div class="cf" id="logoContainer">
                <a href="/index.php">
                    <img src="/images/SiouxValleyCommunityLogo.jpg" alt="Sioux Valley Community Logo CU" id="logoImage">
                    </a>
                      <a href="/creditCard.php"><img src="/images/applyCuNow.jpg" id="topNavAd" width="196" height="113" alt="Apply For Credit Card Now" style="float:right" /></a> </div>
                 <div style="clear:both"></div>
				 
                 
                 <div class="marquee" tabindex="0">
                    <div>
                        <span>
                                        <div><article><div class='news_details'><p><span style="color: #993366;"><strong><span style="font-size: 18pt;">SVCCU will be rolling out a NEW website very soon!!</span></strong></span></p></div></article></div>                
                        </span>
                    </div>
                </div> 
          
      
        </header>
        
        <div id="main" class="contain">
            <aside>
                <div id="olb">
                        <span id="loginBoxHeader"><a href="https://www.financial-net.com/siouxvalleyccu/" target="_blank">ONLINE BANKING</a></span>

               
				</div>
                <nav>
					<div id="loginBtn"><a href="https://www.financial-net.com/siouxvalleyccu/#" target="_blank">Login</a></div>
					<button id="menuBtn" aria-haspopup="true">Menu</button>				
					<div id="nav">
                        <ul role="menubar" aria-label="functions">
                            <li role="menuitem" class="homeMenuLink"><a href="index.html" class="tlmi">Home</a></li>
                            <li role="menuitem" ><a href="" aria-haspopup="true" class="tlmi">
                                <img src="/images/loans.svg" alt="" role="decoration">Apply Online<img src="/images/downArrow.png" width="16" height="12" alt="" role="decoration" class="dropDownArrow"></a>
                                <div role="menu" class="drop">
                                    <ul class="sul">
                                        <li role="menuitem"><a href="/loans.php">Loans</a></li>		
                                        <li role="menuitem"><a href="/creditCard.php">Credit Card</a></li>
                                        <li role="menuitem"><a href="/debitCard.php">Debit Card</a></li>
                                        <li role="menuitem"><a href="/checkingSavings.php">Checking/Savings</a></li>
                                        <li role="menuitem"><a href="/directDeposit.php">Direct Deposit</a></li>
                                        <li role="menuitem"><a href="/emailSignUp.php">Email Sign Up</a></li>
                                    </ul>
                                </div>
                            </li>
                            <li role="menuitem"><a href="/accounts.php" class="tlmi">
                            <img src="/images/products.svg" alt="" role="decoration">Accounts</a>
                            </li>
                            
                                <li role="menuitem"><a href="/eservices.php" aria-haspopup="true"  class="tlmi">
                                <img src="/images/services.svg" alt="" role="decoration">Services<img src="/images/downArrow.png" width="16" height="12" alt="" role="decoration" class="dropDownArrow"></a>
                                <div role="menu" class="drop">
                                    <ul class="sul">
                                        <li role="menuitem"><a href="/services.php">Services</a></li>		
                                        <li role="menuitem"><a href="/eservices.php">Online Services</a></li>
                                    </ul>
                                </div>
                            </li>

<!--                            <li role="menuitem"><a href="https://linkprotect.cudasvc.com/url?a=https%3a%2f%2forders.mainstreetinc.com%2foes%2fmain%2finterfaceportico.aspx&c=E,1,xnnZsBirKe9ZPzW0EQcjQTEolTEG2t2lHFVFAKv2asj0aQZ7Fxez_DOauq1MMjmZltvWHq1Q0766Mr8S3CL-0NB5KNNsndbWV7rP_ctlq4qrkW8,&typo=1" target="_blank"  class="tlmi leaving">-->
							     <li role="menuitem"><a href="https://orders.mainstreetinc.com/ConsumerReorder?UseHeader=Yes&cid=20042" target="_blank"  class="tlmi leaving">
                             	<img src="/images/CashierChecks.svg" alt="" role="decoration">Check Order</a></li>
                             <li role="menuitem"><a href="/rates.php?e=1119" class="tlmi">
                             	<img src="/images/rates.svg" alt="" role="decoration">Rates</a></li>
                             <li role="menuitem"><a href="https://www.uchooserewards.com" class="tlmi leaving">
                             	<img src="/images/uchoose.svg" alt="" role="decoration">uChoose Rewards</a></li>
							<li role="menuitem"><a href="/calculators.php" class="tlmi">
                             	<img src="/images/Calculator.svg" alt="" role="decoration">Calculators</a></li>
                             <li role="menuitem"><a href="/fees.php" class="tlmi">
                                <img src="/images/fees.svg" alt="" role="decoration">Fees</a></li>
                             <li role="menuitem"><a href="/faq.php" class="tlmi">
                                <img src="/images/faq.svg" alt="" role="decoration">FAQ<!--img src="/images/downArrow.png" width="16" height="12" alt="" role="decoration" class="dropDownArrow"--></a>
                                <!--div role="menu" class="drop">
                                    <ul class="sul">
                                        <li role="menuitem"><a href="">Link</a></li>
                                        <li role="menuitem"><a href="">Link</a></li>
                                        <li role="menuitem"><a href="">Link</a></li>
                                        <li role="menuitem"><a href="">Link</a></li>
                                        <li role="menuitem"><a href="">Link</a></li>
                                    </ul>
                                </div-->
                            </li>
                            <li role="menuitem"><a href="/membership.php" class="tlmi">
                                <img src="/images/Become_A_member.svg" alt="" role="decoration">Membership<!--img src="/images/downArrow.png" width="16" height="12" alt="" role="decoration" class="dropDownArrow"--></a>
                                <!--div role="menu" class="drop">
                                    <ul class="sul">
                                        <li role="menuitem"><a href="">Link</a></li>		
                                        <li role="menuitem"><a href="">Link</a></li>
                                    </ul>
                                </div-->
                            </li>
                            <li role="menuitem"><a href="/otherLinks.php" class="tlmi">
                            <img src="/images/links.svg" alt="" role="decoration">Useful Links</a></li>
                             <li role="menuitem"><a href="/siteMap/siteMap.html" class="tlmi">
                            <img src="/images/sitemap.svg" alt="" role="decoration">Site Map</a></li>
                            
                        </ul>
					</div> 
                </nav>
			</aside>
    
			<div id="banner2">
            <h1>Checking & Savings</h1>
            <img src="/images/2019_02_checkingSaving.jpg" width="650" height="366" alt="Checking & Savings Accounts" class="secPageMainImage" /> 

<ul  class="otherLinks">
<!--<li>Click here to enter the <a href="https://www.netit.financial-net.com/siouxvalleyccu-loan" target="_blank">secure checking/savings account application.</a></li>-->
<li>Click here to <a href="http://webadmin.professionalmanagedhosting.com/general_cu/printableApps/CheckingSavingsPrint.asp?InstID=1618" class="leaving" target="_blank">print your checking/savings account application.</a></li>
</ul>
<p>Trouble loading the application? If you are unable to use the links on this page successfully, it may be because you are using a pop-up blocker that is blocking the application. You can correct this by allowing pop-ups on this page or by adding your financial institution's web address and https://webadmin.professionalmanagedhosting.com to your pop-up blocker's list of allowed sites. Be advised that you may have more than one pop-up blocker program enabled, particularly if you have installed additional toolbars to your browser.</p><p>We have invested in VeriSign's secure server digital certificate to protect your data. Through the use of Secure Socket Layer (SSL) technology, the standard for secure communications on the Web, your data is being sent to a secure database and is encrypted to protect your privacy.</p>

        
        
</div>

        
        <!-- end of mainContent -->
</div>
<!-- 
*******************************************************************************************************************
												Footer Info Section - Code Below               
*******************************************************************************************************************
-->
<footer class="contain">
<div id="footerInfoContainer">
<!-- Resource Box 1 -->
<div class="footerInfoBox">
<h2>Important Resources</h2>

<ul>
<li><a href="/application.php" tabindex="0"><span tabindex="-1">Applications</span></a></li>
<li><a href="/eStatement.php" tabindex="0"><span tabindex="-1">eStatement</span></a></li>
<li><a href="/whatsnew.php" tabindex="0"><span tabindex="-1">What's New</span></a></li>
<li><a href="/faq.php" tabindex="0"><span tabindex="-1">FAQ</span></a></li>
<li><a class="leaving" target="_blank" href="https://www.ftc.gov/tips-advice/business-center/small-businesses/cybersecurity/phishing" tabindex="0"><span tabindex="-1">How Phishing Works</span></a></li>
<li><a href="/idTheft.php"  tabindex="0"><span tabindex="-1">ID Theft</span></a></li>
<li><a href="https://co-opcreditunions.org/locator/?ref=co-opsharedbranch.org&sc=1" target="_blank" class="leaving" tabindex="0"><span tabindex="-1">Shared Branching Locations</span></a></li>
<li><a href="https://www.salliemae.com/landing/student-loans/?MPID=1000001373&dtd_cell=SMLRSOPAAGAGAGOTAGC0993N010010" target="_blank" class="leaving" tabindex="0"><span tabindex="-1">SallieMae - Smart Option Student Loan</span></a></li>
	
	<li><a href="#" onClick="window.open('/PDFs/2024_07_SVCCU_SUMMER-2024.pdf')" tabindex="0"><span tabindex="-1">Quarterly Newsletter Summer 2024</span></a></li>
	
	<li><a href="#" onClick="window.open('/PDFs/2024_01_SVCCU_WINTER-rev_2023.pdf')" tabindex="0"><span tabindex="-1">Quarterly Newsletter Winter 2024</span></a></li>

	
<li><a href="#" onClick="window.open('/PDFs/2023_11_SVCCU_SUMMER-2023_updated.pdf')" tabindex="0"><span tabindex="-1">Quarterly Newsletter Summer 2023</span></a></li>	
<!--<li><a href="#" onClick="window.open('../PDFs/2023_08_SVCCU_SUMMER.pdf')" tabindex="0"><span tabindex="-1">Quarterly Newsletter Summer 2023</span></a></li>	

	
	<li><a href="#" onClick="window.open('../PDFs/2021_01_SVCCU_WINTER_2020.pdf')" tabindex="0"><span tabindex="-1">Quarterly Newsletters - Winter 2020 </span></a></li>-->
	<li><a href="#" onClick="window.open('../PDFs/2023_03_SVCCU_SPRING-2023.pdf')" tabindex="0"><span tabindex="-1">Quarterly Newsletter Spring 2023</span></a></li>
	
	
	<li><a href="#" onClick="window.open('/PDFs/2022_12_SVCCU_WINTER-2022.pdf')" tabindex="0"><span tabindex="-1">Quarterly Newsletter Winter 2022</span></a></li>
	
	
<!--	<li><a href="#" onClick="window.open('../PDFs/2022_09_SVCCU_SUMMER-2022.pdf')" tabindex="0"><span tabindex="-1">Quarterly Newsletter Summer 2022</span></a></li>-->

</ul>
</div>

<!-- Resource Box 2 -->
<div class="footerInfoBox">
<div class="footerParagraphContainer">
<p>
The credit union is a member-owned financial cooperative providing banking services including savings, 
loans, and other financial services to members. Membership is also open to immediate family of current members.
<br>
Call us at  <a href="tel:17122771440">712-277-1440</a> 
</p>
</div>
</div>

</div>
<hr class="footerDivider">
	<div>
 
  <div id="footerContent"> 
  <div>
	  <a href="https://co-opcreditunions.org/locator/" target="_blank" class="leaving">
		  <img src="/images/COOP_SharedBranch.png" width="78" height="74" alt="COOP Shared Branch">
	  </a>
	  <a href="https://www.hud.gov/" target="_blank" class="leaving">
		  <img src="/images/EHL.png" width="78" height="74" alt="Equal Lender">
	  </a>
<!--	  <img src="/images/2021_02_BankSafeTrainedSeal-1.png" alt="Bank Safe Trained Seal" width="85%">-->
	  </div>
                
<div><p>Your savings federally insured to at least $250,000 and backed by the full faith and credit <br>of the United States Government Agency
</p>
<p><a href="https://www.siouxvalleyccu.com/PrivacyPolicy.html" target="_blank">Privacy Statement</a> |  <a href="#" onClick="window.open('/PDFs/Disclaimer.pdf')">Disclaimer</a></p>
<!--<p><a href="#" onClick="window.open('/PDFs/SVPrivacy_Act_Brochure.pdf')">Privacy Statement</a> |  <a href="#" onClick="window.open('/PDFs/Disclaimer.pdf')">Disclaimer</a></p>--></div>

            <div><a href="https://www.ncua.gov/" class="leaving" target="_blank"><img src="/images/NCUA.jpg" width="159" height="66" alt="NCUA"></a></div>
            
			
              
          
	</div> 
       
	</div>
<!-- 
*******************************************************************************************************************
											Social Media Fixed Bar - Code Below            
*******************************************************************************************************************
-->
    <div id="socialMediaBottomBar" class="contain">
    	<div id="socialMediaContent">
        	<div><a href="https://www.facebook.com/pages/Sioux-Valley-Community-Credit-Union/168715696478383?ref=hl" target="_blank" class="leaving"><img src="/images/FB.jpg" alt="LES FCU Facebook Account"></a></div>
            <div><a href="#"><img src="/images/YT.jpg" alt="LES FCU Youtube Account"></a></div>
            <div><a href="#"><img src="/images/IN.jpg" alt="LES FCU LinkedIn Account"></a></div>
		</div>
	</div>
        </footer>
<!--
****************************************************************************************************************************
                                         THIRD PARTY SITE DISCLAIMER
****************************************************************************************************************************
--> 
<div class="extDisBg"></div>
	<div id="extDis">
		<div class="extDisBg"></div>
        <div class="extDisMsg">
            <strong><big>THIRD PARTY SITE DISCLAIMER</big></strong> 
            - By accessing the noted link you will be leaving Sioux Valley Community Credit Union website and entering a website hosted by another party.
            Sioux Valley Community Credit Union has not approved this as a reliable partner site. Please be advised that you will no longer be subject to, 
            or under the protection of, the privacy and security policies of Sioux Valley Community Credit Union website. We encourage you to read and 
            evaluate the privacy and security policies of the site you are entering, which may be different than those of Sioux Valley Community Credit Union.
            CLICK OK TO CONTINUE OR CANCEL TO ABORT<br><br><a class="continueBtn btn" target="_blank">Continue</a>
            <a class="closeBtn btn">Cancel</a>
            <div class="cf"></div>
        </div><!-- End extDisMsg -->
	</div>
<!--
****************************************************************************************************************************
                                    End Of THIRD PARTY SITE DISCLAIMER
****************************************************************************************************************************
--> 
        
        <script src="/_inc/rmm.js"></script>
<script>
menu({
	maxSize: 960,
	type: "flyout"
});

</script>
 <script src="/_inc/jq3.js"></script>
 <script src="/_inc/SVC.js"></script>  
    <script src="/_inc/flexslider.js"></script> 
    <script>
        $('.flexslider').flexslider({
        animation: "slide"
        });
    </script> 

 <a href="#" class="cd-top js-cd-top">Top</a>
	  <script src="/_inc/goToTop.js"></script>
</body>
</html>
<!-- 
*******************************************************************************************************************
															The End
*******************************************************************************************************************
-->
